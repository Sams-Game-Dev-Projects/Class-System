using UnityEngine;

namespace ClassSystem.Core
{
    public enum StatType
    {
        Health,
        Mana,
        Strength,
        Intelligence,
        Dexterity,
        Defense,
        ManaRegen,
    }
}

