using UnityEngine;

namespace ClassSystem.Items
{
    [CreateAssetMenu(menuName = "RPG/Weapon Type", fileName = "New WeaponType")]
    public class WeaponType : ScriptableObject
    {
    }
}

